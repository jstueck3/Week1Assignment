package edu.wctc.tinydemo;

public class Main {
    public static void main(String[] args) {
        GreetingWindow greetingWindow = new GreetingWindow();
        greetingWindow.setVisible(true);
    }
}
